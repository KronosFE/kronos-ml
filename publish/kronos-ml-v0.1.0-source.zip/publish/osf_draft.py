#!/usr/bin/env python
"""Create a PRIVATE OSF project (draft) for KODEX and upload the attach set.

DRAFT-FIRST: the project is created with public=false. This script never makes it
public. You review it and flip it to public yourself in the OSF web UI.

    export OSF_TOKEN=...               # osf.io personal access token (scope: osf.full_write)
    python publish/osf_draft.py
"""
from __future__ import annotations
import sys
import requests
from _deposit_common import attach_paths, zenodo_metadata, require_env

API = "https://api.osf.io/v2"
WB = "https://files.osf.io/v1"


def main():
    token = require_env("OSF_TOKEN")
    z = zenodo_metadata()
    h = {"Authorization": f"Bearer {token}"}
    s = requests.Session()

    print("[osf] creating PRIVATE project (draft) ...")
    payload = {"data": {"type": "nodes", "attributes": {
        "title": z["title"], "category": "software",
        "description": "KODEX — the Kronos Family of Codes (AI/ML fusion surrogate suite). "
                       "See CODES.md / BENCHMARKS.md / PROVENANCE.md in the attached archive.",
        "public": False, "tags": z.get("keywords", [])[:25]}}}
    r = s.post(f"{API}/nodes/", headers={**h, "Content-Type": "application/vnd.api+json"},
               json=payload)
    r.raise_for_status()
    node = r.json()["data"]["id"]
    print(f"[osf] node id={node} (private)")

    for path in attach_paths():
        with open(path, "rb") as fh:
            ru = s.put(f"{WB}/resources/{node}/providers/osfstorage/",
                       headers=h, params={"kind": "file", "name": path.name}, data=fh)
        ru.raise_for_status()
        print(f"[osf]   uploaded {path.name}")

    print("\n[osf] PRIVATE project ready (NOT public). Review + make public here:")
    print(f"      https://osf.io/{node}/")


if __name__ == "__main__":
    sys.exit(main())
