#!/usr/bin/env python
"""Create a DRAFT Zenodo deposition for KODEX and upload the attach set.

DRAFT-FIRST: this script NEVER calls the publish action. It creates an unpublished
deposition in your account, uploads the files, writes the metadata, and prints the
edit URL. You review it in the Zenodo web UI and press "Publish" yourself.

    export ZENODO_TOKEN=...            # zenodo.org personal token (scope: deposit:write)
    # optional: export ZENODO_BASE=https://sandbox.zenodo.org   (to rehearse on sandbox)
    python publish/zenodo_draft.py
"""
from __future__ import annotations
import sys
import requests
from _deposit_common import attach_paths, zenodo_metadata, require_env, REPO

BASE = __import__("os").environ.get("ZENODO_BASE", "https://zenodo.org").rstrip("/")


def _api_metadata(z: dict) -> dict:
    """Map .zenodo.json -> the deposition-API metadata block."""
    lic = z.get("license")
    lic = lic["id"] if isinstance(lic, dict) else lic
    m = {"title": z["title"], "upload_type": z.get("upload_type", "software"),
         "description": z["description"], "creators": z["creators"],
         "license": lic, "keywords": z.get("keywords", []),
         "related_identifiers": z.get("related_identifiers", []),
         "version": z.get("version"), "notes": z.get("notes"),
         "language": z.get("language", "eng")}
    return {k: v for k, v in m.items() if v is not None}


def main():
    token = require_env("ZENODO_TOKEN")
    z = zenodo_metadata()
    s = requests.Session()
    p = {"access_token": token}

    print(f"[zenodo] creating DRAFT deposition on {BASE} ...")
    r = s.post(f"{BASE}/api/deposit/depositions", params=p, json={})
    r.raise_for_status()
    dep = r.json()
    dep_id, bucket = dep["id"], dep["links"]["bucket"]
    print(f"[zenodo] draft id={dep_id}")

    for path in attach_paths():
        with open(path, "rb") as fh:
            ru = s.put(f"{bucket}/{path.name}", data=fh, params=p)
        ru.raise_for_status()
        print(f"[zenodo]   uploaded {path.name}")

    rm = s.put(f"{BASE}/api/deposit/depositions/{dep_id}", params=p,
               json={"metadata": _api_metadata(z)})
    rm.raise_for_status()

    edit_url = f"{BASE}/deposit/{dep_id}"
    print("\n[zenodo] DRAFT ready (NOT published). Review + publish here:")
    print(f"         {edit_url}")
    print("[zenodo] to discard: delete the draft in the UI, or DELETE the deposition via API.")


if __name__ == "__main__":
    sys.exit(main())
