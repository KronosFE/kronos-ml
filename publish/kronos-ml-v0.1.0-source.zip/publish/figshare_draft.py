#!/usr/bin/env python
"""Create a DRAFT (private) Figshare article for KODEX and upload the attach set.

DRAFT-FIRST: never calls /publish. Creates a private article, reserves a DOI (a
reservation is not a publication), uploads files via Figshare's multipart flow, and
prints the private article URL for you to review and publish yourself.

    export FIGSHARE_TOKEN=...          # figshare personal token
    python publish/figshare_draft.py
"""
from __future__ import annotations
import hashlib, sys
import requests
from _deposit_common import attach_paths, zenodo_metadata, require_env

API = "https://api.figshare.com/v2"


def _md5(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for c in iter(lambda: f.read(1 << 16), b""):
            h.update(c)
    return h.hexdigest()


def _upload_file(s, h, article_id, path):
    size = path.stat().st_size
    r = s.post(f"{API}/account/articles/{article_id}/files", headers=h,
               json={"name": path.name, "md5": _md5(path), "size": size})
    r.raise_for_status()
    file_url = r.json()["location"]
    info = s.get(file_url, headers=h).json()
    up = s.get(info["upload_url"], headers=h).json()
    with open(path, "rb") as fh:
        for part in up["parts"]:
            fh.seek(part["startOffset"])
            chunk = fh.read(part["endOffset"] - part["startOffset"] + 1)
            s.put(f"{info['upload_url']}/{part['partNo']}", headers=h, data=chunk).raise_for_status()
    s.post(file_url, headers=h).raise_for_status()      # completes the file (not the article)


def main():
    token = require_env("FIGSHARE_TOKEN")
    z = zenodo_metadata()
    h = {"Authorization": f"token {token}"}
    s = requests.Session()

    print("[figshare] creating DRAFT article ...")
    body = {"title": z["title"], "description": z["description"],
            "defined_type": "software", "tags": z.get("keywords", [])[:12],
            "references": [f"https://doi.org/{r['identifier']}" if r["identifier"].startswith("10.")
                           else r["identifier"] for r in z.get("related_identifiers", [])][:20]}
    r = s.post(f"{API}/account/articles", headers=h, json=body)
    r.raise_for_status()
    art_url = r.json()["location"]
    article_id = int(art_url.rstrip("/").split("/")[-1])
    print(f"[figshare] draft article id={article_id}")

    try:
        s.post(f"{API}/account/articles/{article_id}/reserve_doi", headers=h).raise_for_status()
        print("[figshare] DOI reserved (not published)")
    except Exception as e:
        print(f"[figshare] (DOI reserve skipped: {e})")

    for path in attach_paths():
        _upload_file(s, h, article_id, path)
        print(f"[figshare]   uploaded {path.name}")

    print("\n[figshare] DRAFT ready (NOT published). Review + publish here:")
    print(f"           https://figshare.com/account/articles/{article_id}")


if __name__ == "__main__":
    sys.exit(main())
